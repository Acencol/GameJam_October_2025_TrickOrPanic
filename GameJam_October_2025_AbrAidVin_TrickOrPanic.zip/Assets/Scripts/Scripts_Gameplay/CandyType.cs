using UnityEngine;

// Enum for candy types
public enum CandyType
{
    Red,
    Blue,
    Green,
    Purple
}